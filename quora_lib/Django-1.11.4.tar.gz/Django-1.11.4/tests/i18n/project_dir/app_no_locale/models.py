from django.utils.translation import ugettext as _

string = _("This app has no locale directory")
